
const root = document.getElementById('root');
root.innerHTML = `
  <main style="font-family: sans-serif; text-align: center; padding: 2rem;">
    <h1 style="font-size: 2rem;">Teruntuk Zahrah Ghaisani</h1>
    <p>Thank you for all the encouragement you give</p>
    <div style="margin-top: 2rem; display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem;">
      ${["IMG-20250326-WA0013.jpg","IMG-20250328-WA0018.jpg","IMG-20250328-WA0075.jpg","IMG-20250329-WA0013.jpg","IMG-20250330-WA0040.jpg","IMG-20250330-WA0061.jpg"].map(src => `
        <img src='public/${src}' style='width: 100%; border-radius: 12px; box-shadow: 0 4px 8px rgba(0,0,0,0.1);'>
      `).join('')}
    </div>
  </main>
`;
